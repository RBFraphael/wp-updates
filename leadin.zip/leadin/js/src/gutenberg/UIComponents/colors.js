export const CALYPSO = '#00a4bd';
export const CALYPSO_MEDIUM = '#7fd1de';
export const CALYPSO_LIGHT = '#e5f5f8';
export const LORAX = '#ff7a59';
export const OLAF = '#ffffff';
