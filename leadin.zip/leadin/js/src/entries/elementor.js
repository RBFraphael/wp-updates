import { initBackgroundApp } from '../utils/backgroundAppUtils';
// import { getContactProperties } from '../properties/propertiesApi';

function init() {
  // getContactProperties();
}

initBackgroundApp(init);
