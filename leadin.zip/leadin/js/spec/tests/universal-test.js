'use es6';

describe('example test', () => {
  it('universal truth', () => {
    expect(true).toBe(true);
  });
});
