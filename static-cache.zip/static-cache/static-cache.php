<?php
/**
 * Plugin Name: Static Cache
 * Plugin URI: https://github.com/rbfraphael/static-cache
 * Description: Plugin para cache estático
 * Version: 0.0.1
 * Author: RBFraphael
 * Author URI: https://rbfraphael.com.br
 * License: GPL2
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/*
function plugin_init()
{
    // echo $_SERVER['REQUEST_URI'];
    var_dump($_SERVER);

    if(is_page() && !is_admin()){
        load_cached_file(get_the_ID());
    }
}
add_action("pre_get_posts", "plugin_init", 0);

function load_cached_file($id)
{
    $cache_path = WP_CONTENT_DIR."/static-cache";

    if(!is_dir($cache_path)){
        mkdir($cache_path);
    }

    $cached_file = $cache_path."/".$id.".html";

    if(file_exists($cached_file)){
        $file_status = stat($cached_file);
        $time_limit = $file_status['mtime'] + 3600;

        if(time() > $time_limit){
            generate_cached_file($cached_file, $id);
        }

        die(file_get_contents($cached_file));
    }

    generate_cached_file($cached_file, $id);
    die(file_get_contents($cached_file));
}

function generate_cached_file($cached_file, $id)
{
    $content = file_get_contents(get_the_permalink($id));
    $handle = fopen($cached_file, "w");
    fwrite($handle, $content);
    fclose($handle);
}

*/




function _init()
{
    if(!is_user_logged_in()){
        if(!isset($_GET['static_cache_generate'])){
            $path = WP_CONTENT_DIR."/static-cache".$_SERVER['REQUEST_URI']."index.html";
            if(file_exists($path)){
                $file_status = stat($path);
                $time_limit = $file_status['mtime'] + 3600;
                if(time() <= $time_limit){
                    die(file_get_contents($path));
                }
            }
        }
    }
}
add_action("plugins_loaded", "_init", 0);

function _generate_page_cache()
{
    if(!isset($_GET['static_cache_generate'])){
        if(!is_user_logged_in() && is_page()){
            $path = WP_CONTENT_DIR."/static-cache".$_SERVER['REQUEST_URI'];
            $path = strtok($path, "?");
            if(!is_dir($path)){
                mkdir($path, 0777, true);
            }

            $file_path = $path."index.html";
            $content = file_get_contents(get_the_permalink()."?static_cache_generate");
            $header = "<!-- Cached file generated at ".date("Y/m/d H:i:s")." -->";
            $content = $header.PHP_EOL.$content;
            $file = fopen($file_path, "w");
            fwrite($file, $content);
            fclose($file);
        }
    }
}
add_action("shutdown", "_generate_page_cache");

function _update_page_cache($post_ID, $post_after, $post_before)
{
    if($post_after->post_type == "page"){
        $new_link = get_the_permalink($post_after);
        $old_link = get_the_permalink($post_before);
        
        $url = parse_url($new_link);
        $path = WP_CONTENT_DIR."/static-cache".$url['path']."index.html";
        if(file_exists($path)){
            unlink($path);
        }

        $url = parse_url($old_link);
        $path = WP_CONTENT_DIR."/static-cache".$url['path']."index.html";
        if(file_exists($path)){
            unlink($path);
        }
    }
}
add_action("post_updated", "_update_page_cache", 0, 3);