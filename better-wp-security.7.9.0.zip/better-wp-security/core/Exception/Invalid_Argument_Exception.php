<?php

namespace iThemesSecurity\Exception;

class Invalid_Argument_Exception extends \InvalidArgumentException implements Exception {

}
