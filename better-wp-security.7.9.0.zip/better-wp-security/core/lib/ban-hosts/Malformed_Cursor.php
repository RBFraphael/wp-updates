<?php

namespace iThemesSecurity\Ban_Hosts;

use iThemesSecurity\Exception\Invalid_Argument_Exception;

final class Malformed_Cursor extends Invalid_Argument_Exception {

}
