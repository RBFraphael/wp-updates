<?php

return [
	'title' => __( 'Admin User', 'better-wp-security' ),
];
