<?php

require_once( dirname( __FILE__ ) . '/scanner.php' );
ITSEC_File_Change_Scanner::schedule_start( false );